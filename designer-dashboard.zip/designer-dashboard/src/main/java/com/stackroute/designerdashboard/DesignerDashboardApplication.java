package com.stackroute.designerdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesignerDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesignerDashboardApplication.class, args);
	}

}
